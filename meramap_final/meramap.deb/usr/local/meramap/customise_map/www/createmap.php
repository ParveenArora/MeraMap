<?php
$output = shell_exec('./test.sh &');
echo "<pre>$output</pre>";

?>
