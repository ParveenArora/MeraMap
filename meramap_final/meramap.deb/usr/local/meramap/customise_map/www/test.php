<?php
$output = shell_exec('python test.py');
echo "<pre>$output</pre>";
?>
