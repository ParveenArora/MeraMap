echo "it Works"
cd /usr/local/meramap/customise_map/daemon/main
./main.sh
