<?php
$cfgFile = "/usr/local/meramap/customise_map/config/meramap.json";

?>
