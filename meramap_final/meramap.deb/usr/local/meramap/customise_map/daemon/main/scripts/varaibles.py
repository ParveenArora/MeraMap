old_southWest_lat = 75.724
old_southWest_lng = 20.212
old_northEast_lat = 76.047
old_northEast_lng = 30.97
old_minizoomlevel = 8
old_maxzoomlevel = 15
